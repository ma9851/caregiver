---------------------------------------------
To Run Caregiver Application On Windows
---------------------------------------------

1. Enter the directory NodeJSPortable

2. Click NodeJSPortable.exe, a cmd line window should pop up

3. Type in the following command:
	startCaregiver.bat

4.The command line should display the following:
	"Caregiver listening at http://localhost:8888"

2.Open your web browser

3.Naviagate to http://localhost:8888/

4. To close the application, simple close out of the cmd line window

---------------------------------------------
Password to login to caregiver
---------------------------------------------
username: caregiver
Password: password


You can also create a new account and just login with the
username and password you define there 
