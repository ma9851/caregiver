#!/bin/bash

cd caregiver
../NodeJSPortable/node app.js
