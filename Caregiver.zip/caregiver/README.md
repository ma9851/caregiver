# caregiver
Caregiver app for SWEN-444

Install

--WINDOWS--

1. Download and install node.js
2. open a command line
3. navigate to where you downloaded caregiver
4. type in "Node app.js"

The server should just boot up if you did everything correctly

To see the webpage
1. Navigate to localhost:8888 in your browser

Website was tested in Google Chrome
No support was given to older browsers (ex IE)



