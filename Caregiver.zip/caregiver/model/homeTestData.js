var loginUsers = function(){
    var caregiverLogins = [['caregiver','password'],['caregiver1','password1']];
    return caregiverLogins;
};

exports.loginUsers = loginUsers();
